const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const users = () => JSON.parse(localStorage.getItem('pv_users') || '[]');
const saveUsers = u => localStorage.setItem('pv_users', JSON.stringify(u));

// ---------- home: hero carousel + row arrows ----------
const slides = $$('.slide');
if (slides.length) {
  const dots = $('.dots');
  let i = 0, timer;
  slides.forEach((_, n) => {
    const b = document.createElement('button');
    b.setAttribute('aria-label', 'Show featured title ' + (n + 1));
    b.onclick = () => { show(n); restart(); };
    dots.append(b);
  });
  const show = n => {
    i = n;
    slides.forEach((s, k) => s.classList.toggle('on', k === n));
    $$('button', dots).forEach((d, k) => d.classList.toggle('on', k === n));
  };
  const restart = () => { clearInterval(timer); timer = setInterval(() => show((i + 1) % slides.length), 6000); };
  show(0); restart();
}
$$('.rowwrap').forEach(w => {
  const row = $('.row', w);
  $$('.arrow', w).forEach(a => a.onclick = () => row.scrollBy({ left: (a.classList.contains('r') ? 1 : -1) * row.clientWidth * .85 }));
});

// ---------- shared form helpers ----------
function fieldErr(input, text) {
  input.closest('.f').classList.toggle('err', !!text);
  $('.emsg', input.closest('.f')).textContent = text || '';
}
function alertBox(title, text, ok = false) {
  const a = $('.alert');
  a.className = 'alert show' + (ok ? ' ok' : '');
  a.innerHTML = `<b></b><span></span>`;
  $('b', a).textContent = title; $('span', a).textContent = text;
}

// ---------- sign in (two steps: email, then password) ----------
const signin = $('#signin-form');
if (signin) {
  const email = $('#email'), pass = $('#password');
  const s1 = $('#step1'), s2 = $('#step2');
  const q = new URLSearchParams(location.search).get('email');
  if (q) email.value = q;
  $('#continue').onclick = () => {
    if (!emailOk(email.value.trim())) { fieldErr(email, 'Enter a valid email address.'); return; }
    fieldErr(email, '');
    $('.alert').className = 'alert';
    $('#shown').textContent = email.value.trim();
    s1.classList.remove('on'); s2.classList.add('on'); pass.focus();
  };
  email.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#continue').click(); } });
  $('#change').onclick = e => { e.preventDefault(); s2.classList.remove('on'); s1.classList.add('on'); email.focus(); };
  signin.addEventListener('submit', e => {
    e.preventDefault();
    if (!s2.classList.contains('on')) return $('#continue').click();
    if (!pass.value) { fieldErr(pass, 'Enter your password.'); return; }
    fieldErr(pass, '');
    const u = users().find(x => x.email === email.value.trim().toLowerCase());
    if (!u) return alertBox('We cannot find an account with that email', 'Create a new account to start watching.');
    if (u.pass !== btoa(pass.value)) return alertBox('Your password is incorrect', 'Check it and try again.');
    alertBox('Signed in', `Welcome back, ${u.name}!`, true);
    setTimeout(() => (location.href = 'index.html'), 1200);
  });
}

// ---------- create account ----------
const signup = $('#signup-form');
if (signup) {
  const name = $('#name'), email = $('#email'), pass = $('#password'), again = $('#again');
  signup.addEventListener('submit', e => {
    e.preventDefault();
    let bad = false;
    const chk = (el, ok, msg) => { fieldErr(el, ok ? '' : msg); if (!ok) bad = true; };
    chk(name, name.value.trim().length >= 2, 'Enter your name.');
    chk(email, emailOk(email.value.trim()), 'Enter a valid email address.');
    chk(pass, pass.value.length >= 6, 'Minimum 6 characters required.');
    chk(again, pass.value === again.value && again.value !== '', 'Passwords must match.');
    if (bad) return;
    const list = users();
    if (list.some(x => x.email === email.value.trim().toLowerCase()))
      return alertBox('Email address already in use', 'You indicated you are a new customer, but an account already exists with this email.');
    list.push({ name: name.value.trim(), email: email.value.trim().toLowerCase(), pass: btoa(pass.value) }); // demo only
    saveUsers(list);
    alertBox('Account created', 'Taking you to sign in…', true);
    setTimeout(() => (location.href = 'signin.html?email=' + encodeURIComponent(email.value.trim())), 1200);
  });
}
