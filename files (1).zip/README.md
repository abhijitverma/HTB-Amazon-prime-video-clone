# Prime Video Clone: Website Copy Project

GDG on Campus SRM 2026-27 · Technical Domain · 1st Year Website Copy Project

A recreation of the Amazon Prime Video landing, sign-in and registration pages in plain HTML, CSS and JavaScript (no build step).

## Pages
- `index.html`: landing page with auto-rotating hero, scrollable rows (Originals, Top 10, Recommended), join banner, footer
- `signin.html`: two-step sign in (email, then password) with error banners
- `signup.html`: account creation with name, email, password and password-match validation

## How it works
Accounts live in `localStorage`, so the whole flow works without a backend (demo only: passwords are not stored securely).

## Run
Open `index.html`, or run `python3 -m http.server` in this folder.

## Notes
All titles and artwork are fictional placeholders (CSS gradients). Not affiliated with Amazon.
